package org.cctve;

import java.util.ArrayList;
import java.util.List;

public class Gerencia {
    private List<Abonado> abonadoList = new ArrayList<>();
    private List<Solicitud> solicitudList=new ArrayList<>();
    private  List<Cuadrilla> cuadrillaList= new ArrayList<>();
    private List<VisitaTecnica> visitaTecnicaList= new ArrayList<>();


    public void addAbonado(Abonado c){
        abonadoList.add(c);

    }

    public void listarAbonados(){
        System.out.println("lista abonados");
        for (Abonado c : abonadoList){
            System.out.println("nombre : "+ c.getNombre());
        }

    }

    public void informesSolicitudesPorMarca() {
        System.out.println("=== SOLICITUDES POR MARCA ===");
        List<String> marcas = new ArrayList<>();
        for (Solicitud s : solicitudList) {
            if (s.getModemRoto() != null && !marcas.contains(s.getModemRoto().getMarca())) {
                marcas.add(s.getModemRoto().getMarca());
            }
        }
        for (String marca : marcas) {
            int contador = 0;
            for (Solicitud s : solicitudList) {
                if (s.getModemRoto() != null && marca.equals(s.getModemRoto().getMarca())) {
                    contador++;
                }
            }
            System.out.println(" - " + marca + ": " + contador + " solicitud(es)");
        }
    }



}
