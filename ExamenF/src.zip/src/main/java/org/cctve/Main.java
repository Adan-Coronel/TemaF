package org.cctve;

public class Main {
    static void main() {
        Domicilio domicilioAdan = new Domicilio("calle","falsa","siempre Viva",123);
        Abonado c1= new Abonado("Adan","adan@ulp.com",domicilioAdan,"222222",123);
        Abonado c2 = new Abonado("jhoel","jhoel@ulp.com", new Domicilio("9 de julio","richeri","centro", 1544),"333333",123);




        Gerencia gerencia = new Gerencia();
        gerencia.addAbonado(c1);
        gerencia.addAbonado(c2);
        gerencia.listarAbonados();

    }
}
